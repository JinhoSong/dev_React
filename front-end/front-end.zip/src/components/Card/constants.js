export default [
  {
    category: "마우스",
    subtitle: "sub part",
    avatarSrc:
      "https://shopping-phinf.pstatic.net/main_1272533/12725335936.20180607174129.jpg?type=f60",
    imgSrc:
      "https://shopping-phinf.pstatic.net/main_1272533/12725335936.1.20180607174129.jpg?type=f300",
    description: "간단한 제품 정보1",
  },
  {
    category: "노트북",
    subtitle: "sub part",
    avatarSrc:
      "https://shopping-phinf.pstatic.net/main_1272533/12725335936.20180607174129.jpg?type=f60",
    imgSrc:
      "https://shopping-phinf.pstatic.net/main_1272533/12725335936.1.20180607174129.jpg?type=f300",
    description: "간단한 제품 정보2",
  },
  {
    category: "썬크림",
    subtitle: "sub part",
    avatarSrc:
      "https://shopping-phinf.pstatic.net/main_1272533/12725335936.20180607174129.jpg?type=f60",
    imgSrc:
      "https://shopping-phinf.pstatic.net/main_1272533/12725335936.1.20180607174129.jpg?type=f300",
    description: "간단한 제품 정보3",
  },
  {
    category: "스킨",
    subtitle: "sub part",
    avatarSrc:
      "https://shopping-phinf.pstatic.net/main_1536959/15369599180.20181002114630.jpg?type=f300",
    imgSrc:
      "https://shopping-phinf.pstatic.net/main_1536959/15369599180.20181002114630.jpg?type=f300",
    description: "간단한 제품 정보4",
  },
  {
    category: "title part",
    subtitle: "sub part",
    avatarSrc:
      "https://shopping-phinf.pstatic.net/main_1536959/15369599180.20181002114630.jpg?type=f300",
    imgSrc:
      "https://shopping-phinf.pstatic.net/main_1536959/15369599180.20181002114630.jpg?type=f300",
    description: "간단한 제품 정보5",
  },
  {
    category: "title part",
    subtitle: "sub part",
    avatarSrc:
      "https://shopping-phinf.pstatic.net/main_1536959/15369599180.20181002114630.jpg?type=f300",
    imgSrc:
      "https://shopping-phinf.pstatic.net/main_1536959/15369599180.20181002114630.jpg?type=f300",
    description: "간단한 제품 정보6",
  },
];
